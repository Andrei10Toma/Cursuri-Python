"""empty message

Revision ID: c65e5b281a7e
Revises: 
Create Date: 2020-12-22 12:33:51.381572

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c65e5b281a7e'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
